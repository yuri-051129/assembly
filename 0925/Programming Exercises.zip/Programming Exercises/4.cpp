#include <stdio.h>

#define GREETING "Hello"
#define FAREWELL "Goodbye"
#define NAME "Yuri"
#define CITY "Seoul"

int main() {
    char message1[] = GREETING;
    char message2[] = FAREWELL;
    char person[] = NAME;
    char place[] = CITY;

    printf("%s, %s! Welcome to %s.\n", message1, person, place);
    printf("%s, %s!\n", message2, person);

    return 0;
}

