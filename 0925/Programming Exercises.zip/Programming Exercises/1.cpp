#include <stdio.h>

int main() {
    int EAX = 10; 
    int EBX = 5;  
    int ECX = 3;  
    int EDX = 2;  

    int TEMP1 = EAX + EBX;
    int TEMP2 = ECX + EDX;
    EAX = TEMP1 - TEMP2;

    printf("%d\n", EAX);

    return 0;
}

