#include <stdio.h>

#define MONDAY    1
#define TUESDAY   2
#define WEDNESDAY 3
#define THURSDAY  4
#define FRIDAY    5
#define SATURDAY  6
#define SUNDAY    7

int main() {
    int week[7] = {MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY};

    for(int i = 0; i < 7; i++) {
        printf("%d ", week[i]);
    }
    printf("\n");

    return 0;
}

