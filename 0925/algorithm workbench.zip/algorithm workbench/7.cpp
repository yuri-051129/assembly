#include <stdint.h>  
#include <stdio.h>

int main() {
    uint32_t array[120];

    printf("First element (uninitialized): %u\n", array[0]);
    printf("Last element (uninitialized): %u\n", array[119]);

    return 0;
}

