#include <stdio.h>

int main() {
    char favoriteColor[] = "pastel Blue"; 

    printf("%s\n", favoriteColor);

    return 0;
}

