#include <stdint.h>
#include <stdio.h>

int main() {
    int32_t dArray[50];

    printf("%d %d\n", dArray[0], dArray[49]);

    return 0;
}

