#include <stdio.h>
#include <stdint.h>

int main() {
    uint8_t alphabet[5] = {'A', 'B', 'C', 'D', 'E'};

    for (int i = 0; i < 5; i++) {
        printf("%c ", alphabet[i]);
    }

    return 0;
}

