#include <stdio.h>
#include <stdint.h>

int main() {
    uint32_t doubleword = 0x12345678;  
    uint8_t memory[4];                 
   
    memory[0] = (doubleword >> 24) & 0xFF; 
    memory[1] = (doubleword >> 16) & 0xFF;
    memory[2] = (doubleword >> 8) & 0xFF;
    memory[3] = doubleword & 0xFF;          

    for (int i = 0; i < 4; i++) {
        printf("%02X ", memory[i]);
    }

    return 0;
}

