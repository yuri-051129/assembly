#include <stdio.h>
#include <stdint.h>

int main() {
    uint8_t bArray[20] = {0}; 

    for (int i = 0; i < 20; i++) {
        printf("%u ", bArray[i]);
    }
    printf("\n");

    return 0;
}

