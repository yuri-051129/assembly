#include <stdio.h>
#include <stdint.h>

int main() {
    uint32_t myDWORD;  
    myDWORD = -5;      

    printf("myDWORD = %u\n", myDWORD); 
    printf("myDWORD (hex) = 0x%X\n", myDWORD); 

    return 0;
}

