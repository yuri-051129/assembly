#include <stdio.h>

const int DATA1 = 10;
const int DATA2 = 20;

void CodeSegment1() {
    printf("This is Code Segment 1\n");
}

void CodeSegment2() {
    printf("This is Code Segment 2\n");
}

int main() {
    CodeSegment1();
    CodeSegment2();

    printf("Data1: %d\n", DATA1);
    printf("Data2: %d\n", DATA2);

    return 0;
}

