#include <stdio.h>

#define DECIMAL_25 25      
#define BINARY_25 0b11001   
#define OCTAL_25 031      
#define HEX_25 0x19        

int main() {
    printf("Decimal: %d\n", DECIMAL_25);
    printf("Binary: %d\n", BINARY_25);
    printf("Octal: %d\n", OCTAL_25);
    printf("Hexadecimal: %d\n", HEX_25);

    return 0;
}

