#include <stdio.h>
#include <stdint.h>

int main() {
    int32_t minValue = -2147483648;

    printf("%d\n", minValue);

    return 0;
}

