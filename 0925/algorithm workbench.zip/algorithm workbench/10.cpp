#include <stdio.h>
#include <stdint.h>

int main() {
    uint16_t wArray[3] = {1000, 2000, 3000};

    for (int i = 0; i < 3; i++) {
        printf("%u ", wArray[i]);
    }
    printf("\n");

    return 0;
}

